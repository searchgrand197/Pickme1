from django.db import models
import uuid

class Devicelist(models.Model):
    id = models.UUIDField(default=uuid.uuid4,primary_key=True,unique=True,editable=True)
    hostel_name = models.CharField(max_length=20,null=True)
    room_num = models.IntegerField()
    pickme_serial_num = models.IntegerField(unique=True)
    pickme_mac_name = models.CharField(max_length=200,editable=True)
    student_id = models.CharField(max_length=8,blank=True,null=True)
    rfid = models.CharField(max_length=11,blank=True,null=True)
    student_id2 = models.CharField(max_length=8,blank=True,null=True)
    rfid2 = models.CharField(max_length=11,blank=True,null=True)
    student_id3 = models.CharField(max_length=8,blank=True,null=True)
    rfid3 = models.CharField(max_length=11,blank=True,null=True)
    student_id4 = models.CharField(max_length=8,blank=True,null=True)
    rfid4 = models.CharField(max_length=11,blank=True,null=True)
    student_id5 = models.CharField(max_length=8,blank=True,null=True)
    rfid5 = models.CharField(max_length=11,blank=True,null=True)
    student_id6 = models.CharField(max_length=8,blank=True,null=True)
    rfid6 = models.CharField(max_length=11,blank=True,null=True)
    student_id7 = models.CharField(max_length=8,blank=True,null=True)
    rfid7 = models.CharField(max_length=11,blank=True,null=True)
    student_id8 = models.CharField(max_length=8,blank=True,null=True)
    rfid8 = models.CharField(max_length=11,blank=True,null=True)
    # nece_power = models.CharField(max_length=20,blank=True,null=True) 
    nece_power = models.CharField(max_length=20,blank=True,null=True,default=0) 


    def __str__(self):

        return self.hostel_name