from django.urls import path
from . import views
urlpatterns = [
    path('login/', views.loginPage, name="login"),
    path('logout/', views.logoutUser, name="logout"),
    path('change/', views.change_device, name="change"),
    path('malfunction/', views.malfunction_device, name="malfunction"),
    path('nece/', views.nece_device, name="nece"),
    path('faq/', views.FAQ, name="faq"),
    path('upload/', views.simple_upload,name="upload"),
    path('', views.device_list, name='device-list'),
    path('search/', views.device_list2, name='device-list2'),
    path('create/', views.device_create, name='create-device'),
    path('edit/<str:pk>/', views.edit_device, name='edit-device'),
    path('delete/<str:pk>/', views.delete_device, name='delete-device'),

    # Trying to delete postion using ajax
    path('delete_position', views.delete_position, name="delete-position"),
     path('manage_positions', views.manage_positions, name="manage_positions-page"),
    #  path('add_manage_position', views.add_manage_position, name="add_manage_positions"),
     path('save_position', views.save_position, name="save-position-page"),


]