from django import forms
from django.forms import ModelForm
from .models import Devicelist

class Deviceform(ModelForm):
    class Meta:
        model = Devicelist
        
        fields = ('id','pickme_mac_name','pickme_serial_num','room_num', 'hostel_name', 'student_id', 'rfid', 'student_id2', 'rfid2', 'student_id3', 'rfid3', 'student_id4', 'rfid4', 'student_id5', 'rfid5', 'student_id6', 'rfid6', 'student_id7', 'rfid7','student_id8', 'rfid8','nece_power')

        widgets = {
            'id': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'id','readonly':'readonly'}),
            'hostel_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Hostel_Name'}),
            'room_num': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Room_Num.'}),
            'pickme_serial_num': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Pickme_Serial'}),
            'pickme_mac_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Pickme_Mac'}),
            'student_id': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Student_1_ID ex. 11991122'}),
            'rfid': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'RFID 1'}),
            'student_id2': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Student_2_ID ex. 11991122'}),
            'rfid2': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'RFID 2'}),
            'student_id3': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Student_3_ID ex. 11991122'}),
            'rfid3': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'RFID 3'}),
            'student_id4': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Student_4_ID ex. 11991122'}),
            'rfid4': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'RFID 4'}),
            'student_id5': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Student_5_ID ex. 11991122'}),
            'rfid5': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'RFID 5'}),
            'student_id6': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Student_6_ID ex. 11991122'}),
            'rfid6': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'RFID 6'}),
            'student_id7': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Student_7_ID ex. 11991122'}),
            'rfid7': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'RFID 7'}),
            'student_id8': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Student_8_ID ex. 11991122'}),
            'rfid8': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'RFID 8'}),
            'nece_power': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'NP (add 0 or 1)','disabled':'true'}),

        }