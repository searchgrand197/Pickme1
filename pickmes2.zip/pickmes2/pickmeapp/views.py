from django.shortcuts import render, redirect
from django.db.models import Q
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from .models import Devicelist
from .forms import Deviceform
from django.core.paginator import Paginator
from django.shortcuts import render
from django.http import HttpResponse
from .resources import DevicelistResources
from tablib import Dataset
import uuid
import boto3
import json
import os
import pathlib

client = boto3.Session(
    aws_access_key_id = "AKIA3O377A4CJ3FHDB7E",
    aws_secret_access_key = "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",
)
dynamodb = client.resource('dynamodb')

table = dynamodb.Table('Dashboard')

# Upload File
@login_required(login_url='login')
def simple_upload(request):
    if request.method == 'POST':
        person_resource = DevicelistResources()
        dataset = Dataset()
        try:
            new_persons = request.FILES['myfile']
            print("This is new person",new_persons)
            print('Type is ',type(new_persons))
            imported_data = dataset.load(new_persons.read(),format='xls')
            # print("This is imported file",imported_data)
            # n = len(imported_data[0])
            # print(n)
            # for i in range(n):

            #     print(imported_data[0][i])
        

            for data in imported_data:
                myuuid = uuid.uuid4()
                value = Devicelist(
                    myuuid,
                    data[1],
                    data[2],
                    data[3],
                    data[4],
                    # data[5],
                    data[6],
                    data[7],
                    data[8],
                    data[9],
                    data[10],
                    data[11],
                    data[12],
                    data[13],
                    data[14],
                    data[15],
                    data[16],
                    data[17],
                    data[18],
                    data[19],
                    data[20],
                    data[21],
                    data[22],
                )
                # value = Devicelist(
                #     myuuid,
                #     data[1],
                #     data[2],
                #     data[3],
                #     data[4],
                #     data[5],
                #     data[6],
                #     data[7],
                #     data[8],
                # )
                value.save()


                # Before
                # 2 3 6 8 all should be converted to integer.
                # new_id=str(myuuid)
                # new_room = int(data[3])
                # new_serial_num = int(data[2])
                # new_stu_id = int(data[6])
                
                # new_nece = int(data[8])
                # print("Room type is ",type(data[1]))
                # print("Serial number type is ",type(data[6]))
                # print("nece type is ",type(data[8]))

                # Now (11/12/2022)
                new_id=str(myuuid)
                new_room = int(data[3])
                new_serial_num = int(data[2])
                new_stu_id = int(data[6])
                new_stu_id2 = int(data[7])
                new_stu_id3 = int(data[8])
                new_stu_id4 = int(data[9])
                new_stu_id5 = int(data[10])
                new_stu_id6 = int(data[11])
                new_stu_id7 = int(data[12])
                new_stu_id8 = int(data[13])
                
                new_nece = int(data[22])
                table.put_item(
                    Item={
                        'id' : new_id,
                        'Hoste_name':data[4],
                        'Room_num':new_room,
                        'Serial_num':new_serial_num,
                        'pickme_mac_name': data[1],
                        'Student_id':new_stu_id,
                        'RFID':data[14],
                        'Student_id2':new_stu_id2,
                        'RFID2':data[15],
                        'Student_id3':new_stu_id3,
                        'RFID3':data[16],
                        'Student_id4':new_stu_id4,
                        'RFID4':data[17],
                        'Student_id5':new_stu_id5,
                        'RFID5':data[18],
                        'Student_id6':new_stu_id6,
                        'RFID6':data[19],
                        'Student_id7':new_stu_id7,
                        'RFID7':data[20],
                        'Student_id8':new_stu_id8,
                        'RFID8':data[21],
                        'nece_power':new_nece, 
                    }
                )

            return redirect('device-list')
        except:
            messages.info(request, 'Not Able to Upload')
    #print(uuid)
    return render(request, 'pickmeapp/upload.html')
@login_required(login_url='login')
def device_list2(request):
    search_query = ""

    if request.GET.get('search_query'):
        search_query = request.GET.get('search_query')

    device_list = Devicelist.objects.filter(
        Q(room_num__icontains=search_query) |
        Q(student_id__icontains=search_query) |
        Q(student_id2__icontains=search_query) |
        Q(student_id3__icontains=search_query) |
        Q(student_id4__icontains=search_query) |
        Q(student_id5__icontains=search_query) |
        Q(student_id6__icontains=search_query) |
        Q(student_id7__icontains=search_query) |
        Q(student_id8__icontains=search_query)
    )

    context = {
        'devicelist': device_list,
        'search_query': search_query,
    }
    return render(request, 'pickmeapp/list.html', context)


# Device List
@login_required(login_url='login')
def device_list(request):
    global dl_total                                     # Global dl_total
    search_query = ""
    
    if request.GET.get('search_query'):
        search_query = request.GET.get('search_query')

    # device_list = Devicelist.objects.filter(
    device_list = Devicelist.objects.filter()
    nece_devicelist=Devicelist.objects.filter(nece_power=1)
    nece_total=len(nece_devicelist)
    #print(nece_total)
    dl_total = len(device_list)
    paginator = Paginator(device_list,10) # if want to escape from unorder warning write .orderby('id or anything else')
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'dl_total':dl_total,
        # 'cl_total':cl_total,
        # 'ml_total':ml_total,
        'nece_total':nece_total,
        'mac':device_list,# changing for mac device
        'devicelist': page_obj,
        'page_obj':page_obj,
        'search_query': search_query,
    }
    return render(request, 'pickmeapp/list.html', context)



# Create Device
@login_required(login_url='login')
def device_create(request):

    form = Deviceform()
    if request.method == 'POST':

        form = Deviceform(request.POST, request.FILES)
        print(request.FILES)
        if form.is_valid():
            new_id=form.cleaned_data['id']
            new_hostel_name=form.cleaned_data['hostel_name']
            new_room_num=form.cleaned_data['room_num']
            new_pickme_serial_num=form.cleaned_data['pickme_serial_num']
            new_pickme_mac_name=form.cleaned_data['pickme_mac_name']
            new_student_id=form.cleaned_data['student_id']
            new_rfid=form.cleaned_data['rfid']
            new_student_id2=form.cleaned_data['student_id2']
            new_rfid2=form.cleaned_data['rfid2']
            new_student_id3=form.cleaned_data['student_id3']
            new_rfid3=form.cleaned_data['rfid3']
            new_student_id4=form.cleaned_data['student_id4']
            new_rfid4=form.cleaned_data['rfid4']
            new_student_id5=form.cleaned_data['student_id5']
            new_rfid5=form.cleaned_data['rfid5']
            new_student_id6=form.cleaned_data['student_id6']
            new_rfid6=form.cleaned_data['rfid6']
            new_student_id7=form.cleaned_data['student_id7']
            new_rfid7=form.cleaned_data['rfid7']
            new_student_id8=form.cleaned_data['student_id8']
            new_rfid8=form.cleaned_data['rfid8']
            new_nece_power=form.cleaned_data['nece_power']

            new_id=str(new_id)

            table.put_item(
                Item={
                    'id' : new_id,
                    'Hoste_name':new_hostel_name,
                    'Room_num':new_room_num,
                    'Serial_num':new_pickme_serial_num,
                    'pickme_mac_name': new_pickme_mac_name,
                    'Student_id':new_student_id,
                    'RFID':new_rfid,
                    'Student_id2':new_student_id2,
                    'RFID2':new_rfid2,
                    'Student_id3':new_student_id3,
                    'RFID3':new_rfid3,
                    'Student_id4':new_student_id4,
                    'RFID4':new_rfid4,
                    'Student_id5':new_student_id5,
                    'RFID5':new_rfid5,
                    'Student_id6':new_student_id6,
                    'RFID6':new_rfid6,
                    'Student_id7':new_student_id7,
                    'RFID7':new_rfid7,
                    'Student_id8':new_student_id8,
                    'RFID8':new_rfid8,
                    'nece_power':new_nece_power,
                }
            )
            form.save()
            return redirect('device-list')

    context = {
        'form': form,
    }
    return render(request, 'pickmeapp/create.html', context)


# Edit Device
@login_required(login_url='login')
def edit_device(request,pk):
    device = Devicelist.objects.get(id=pk)

    form = Deviceform(instance=device)

    if request.method == 'POST':
        form = Deviceform(request.POST, request.FILES, instance=device)
        if form.is_valid():
            enew_id=form.cleaned_data['id']
            enew_hostel_name=form.cleaned_data['hostel_name']
            enew_room_num=form.cleaned_data['room_num']
            enew_pickme_serial_num=form.cleaned_data['pickme_serial_num']
            enew_pickme_mac_name=form.cleaned_data['pickme_mac_name']
            enew_student_id=form.cleaned_data['student_id']
            enew_rfid=form.cleaned_data['rfid']
            enew_nece_power=form.cleaned_data['nece_power']
            enew_id=str(enew_id)
            table.update_item(
                Key={
                    'id': enew_id,
                },
                UpdateExpression="SET Hoste_name = :h,Room_num= :c",
                ExpressionAttributeValues={
                    ':s': enew_hostel_name,
                    ':c': enew_room_num,

                },
            )
            # edit_emp_name=form.cleaned_data['emp_name']
            # edit_emp_email=form.cleaned_data['emp_email']
            # edit_emp_contact=form.cleaned_data['emp_contact']
            # edit_emp_role=form.cleaned_data['emp_role']
            # edit_emp_salary=form.cleaned_data['emp_salary']emp_salary
            # table.update_item(
            #     Key={
            #         'Name': edit_emp_name,
            #         'Email': edit_emp_email,
            #     },
            #     UpdateExpression="SET Salary= :s,Contact= :c",
            #     ExpressionAttributeValues={
            #         ':s': edit_emp_salary,
            #         ':c': edit_emp_contact,
            #
            #     },
            #     ReturnValues="UPDATED_NEW"
            # )
            form.save()
            return redirect('device-list')

    context = {
        'device': device,
        'form': form,
    }
    return render(request, 'pickmeapp/edit.html', context)

#delete_position
@login_required
def delete_position(request):
    data =  request.POST
    resp = {'status':''}
    try:
        Devicelist.objects.filter(id = data['id[]']).delete()
        table.delete_item(
            Key={
                'id':data['id[]'],
            }
        )

        resp['status'] = 'success'
    except:
        resp['status'] = 'failed'
    return HttpResponse(json.dumps(resp), content_type="application/json")

# Delete Device
@login_required(login_url='login')
def delete_device(request,pk):
    device = Devicelist.objects.get(id=pk)
    if request.method == 'POST':
        table.delete_item(
            Key={
                'id':pk,
            }
        )
        device.delete()
        return redirect('device-list')


    context = {
        'device': device,
    }
    return render(request, 'pickmeapp/delete.html',context)

# @login_required(login_url='login')
# def change_device(request,pk):

# @login_required(login_url='login')
# def malfunction(request,pk):



# Login
def loginPage(request):
    if request.user.is_authenticated:
        return redirect('device-list')
    else:
        if request.method == 'POST':
            username = request.POST.get('username')
            password =request.POST.get('password')

            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)
                return redirect('device-list')
            else:
                messages.info(request, 'Username OR password is incorrect')

        context = {}
        return render(request, 'pickmeapp/login.html', context)


# Logout
def logoutUser(request):
    logout(request)
    return redirect('login')


# Change Device
def change_device(request):
    # global cl_total                             # Global cl_total
    change_devices = Devicelist.objects.all()
    alldevices = len(Devicelist.objects.all())
    necech_devices = Devicelist.objects.filter(nece_power=1)
    necechdevices = len(necech_devices)
    cl_total = len(change_devices)
    context={
        'dl_total':alldevices,
        #'cl_total':cl_total,
        # 'ml_total':ml_total,
        'nece_total':necechdevices,
    }
    return render(request,'pickmeapp/change.html',context)

# Malfunction Device
def malfunction_device(request):
    # global ml_total                             # Global ml_total
    mal_devices = Devicelist.objects.all()
    necemal_devices = Devicelist.objects.filter(nece_power=1)
    necemaldevices = len(necemal_devices)
    alldevices = len(Devicelist.objects.all())
    ml_total = len(mal_devices)
    context={
        'dl_total':alldevices,
        # 'cl_total':cl_total,
        'ml_total':ml_total,
        'nece_total':necemaldevices,
    }
    return render(request,'pickmeapp/malfunction.html',context)

#Contact US
def FAQ(request):
    return render(request,'pickmeapp/FAQ.html')


# NECE Device
@login_required(login_url='login')
def nece_device(request):                       # Global nece_total
    search_query = ""
    if request.GET.get('search_query'):
        search_query = request.GET.get('search_query')

    # device_list = Devicelist.objects.filter()
    device_list = Devicelist.objects.filter()
    device_list_len=len(device_list)
    nece_device_list = Devicelist.objects.filter(nece_power=1)
    nece_total = len(nece_device_list)
    paginator = Paginator(nece_device_list,10) # if want to escape from unorder warning write .orderby('id or anything else')
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'dl_total':device_list_len,
        # 'cl_total':cl_total,
        # 'ml_total':ml_total,
        'nece_total':nece_total,
        'mac':device_list,# changing for mac device
        'devicelist': page_obj,
        'page_obj':page_obj,
        'search_query': search_query,
    }
    return render(request, 'pickmeapp/nece.html', context)



# Manage position function based view

@login_required
def manage_positions(request):
    position = {}
    if request.method == 'GET':
        data =  request.GET
        id = ''
        #print("THIS IS DATA INSIDE MANAGE POSITION FUNCTION ",data)
        if 'id' in data:
            id= data['id']
            position = Devicelist.objects.get(id=id)
            #print("This is position ", position.rfid)
    context = {
        'position' : position
    }
    return render(request, 'pickmeapp/manage_position.html',context)


# @login_required
# def add_manage_position(request):
#     position = {}
#     if request.method == 'GET':
#         data =  request.GET
#         id = ''
#         #print("THIS IS DATA INSIDE MANAGE POSITION FUNCTION ",data)
#         if 'id' in data:
#             id= data['id']
#             position = Devicelist.objects.get(id=id)
#             #print("This is position ", position.rfid)
#     context = {
#         'position' : position
#     }
#     return render(request, 'pickmeapp/manage_position.html',context)

@login_required
def save_position(request):
    data =  request.POST
    #print("Inside save position fucntion ",data)
    resp = {'status':'failed'}
    try:
        if ( data['id'] != 0) :
            #save_position = Devicelist.objects.filter(id = data['id']).update(name=data['name'], description = data['description'],status = data['status'])
            save_position = Devicelist.objects.filter(id = data['id']).update(rfid=data['name'],student_id=data['ID'],rfid2=data['name2'],student_id2=data['ID2'],rfid3=data['name3'],student_id3=data['ID3'],rfid4=data['name4'],student_id4=data['ID4'],rfid5=data['name5'],student_id5=data['ID5'],rfid6=data['name6'],student_id6=data['ID6'],rfid7=data['name7'],student_id7=data['ID7'],rfid8=data['name8'],student_id8=data['ID8'],nece_power=data['nece'])
            table.update_item(
                Key={
                    'id': data['id'],
                },
                UpdateExpression="SET RFID = :h, RFID2= :i, RFID3 = :j, RFID4 = :k, RFID5 = :l,RFID6 = :m,RFID7 = :n,RFID8 = :o,Student_id = :a,Student_id2 = :b,Student_id3 = :c,Student_id4 = :d,Student_id5 = :e,Student_id6 = :f,Student_id7 = :g,Student_id8 = :z,nece_power=:p",
                ExpressionAttributeValues={

                    ':h': data['name'],
                    ':i': data['name2'],
                    ':j': data['name3'],
                    ':k': data['name4'],
                    ':l': data['name5'],
                    ':m': data['name6'],
                    ':n': data['name7'],
                    ':o': data['name8'],
                    ':a': data['ID'],
                    ':b': data['ID2'],
                    ':c': data['ID3'],
                    ':d': data['ID4'],
                    ':e': data['ID5'],
                    ':f': data['ID6'],
                    ':g': data['ID7'],
                    ':z': data['ID8'],
                    ':p': data['nece'],

                },
            )


        else:
            #save_position = Devicelist(name=data['name'], description = data['description'],status = data['status'])
            save_position = Devicelist(rfid=data['name'],student_id=data['ID'],nece_power=data['nece'])
            save_position.save()
        resp['status'] = 'success'
    except:
        resp['status'] = 'failed'
    return HttpResponse(json.dumps(resp), content_type="application/json")