from import_export import resources
from .models import Devicelist

class DevicelistResources(resources.ModelResource):
    class meta:
        model = Devicelist